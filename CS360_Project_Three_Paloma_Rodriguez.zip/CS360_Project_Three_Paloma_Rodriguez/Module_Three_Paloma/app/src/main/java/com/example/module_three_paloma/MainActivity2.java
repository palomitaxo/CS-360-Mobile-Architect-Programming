package com.example.module_three_paloma;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity implements TextWatcher {

    EditText userEditText;
    EditText passwordEditText;
    Button submitButton;
    TextView passwordMessageTextView;
    UserDB userDB;
    UserModel validUser;
    WeightDB weightDB;
    private DialogInterface.OnClickListener dialogClickListener;

    private void loginSuccess(View view, String username) {
        weightDB = WeightDB.getInstance(this);
        validUser = UserModel.getUserInstance();
        validUser.setUserName(username);
        validUser.setGoal(weightDB.getGoal(validUser));

        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.editTextTextPassword);
        submitButton = findViewById(R.id.buttonSayHello);
        passwordMessageTextView = findViewById(R.id.textView5);

        userDB = UserDB.getInstance(this);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = userEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                boolean validUsername = userDB.checkUserName(username);
                boolean validPassword = userDB.checkUserPassword(username, password);

                if (validUsername) {
                    if (validPassword) {
                        Toast.makeText(MainActivity.this, "Successful Login", Toast.LENGTH_SHORT).show();
                        loginSuccess(v, username);
                    } else {
                        Toast.makeText(MainActivity.this, "Please Try Again", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder
                            .setTitle("Account Not Found")
                            .setMessage("New User?")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Boolean userAdded = userDB.insertUser(username, password);

                                    if (userAdded) {
                                        Toast.makeText(MainActivity.this, "Account Added", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton("No", null)
                            .show();
                }
            }
        });

        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 5) {
                    passwordMessageTextView.setVisibility(View.VISIBLE);
                } else {
                    passwordMessageTextView.setVisibility(View.INVISIBLE);
                    submitButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }
}
